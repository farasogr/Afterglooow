CREATE TABLE "creations" (
	"id" uuid PRIMARY KEY,
	"owner_id" text NOT NULL,
	"title" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
CREATE INDEX "creations_owner_idx" ON "creations" ("owner_id");